package operaciones.aritmeticas;

public class Data 
{
	//estos datos se podrian calcular al azar
	public static final int numeroSimbolos = 5;				//numero de simbolos a elegir
	public static final int numeros[] = {75, 50, 6, 3, 9, 7};	//en total hay "numeroSimbolos+1" numeros
	public static final int resultadoObjetivo = 248;			//nuestro objetivo a conseguir
}
