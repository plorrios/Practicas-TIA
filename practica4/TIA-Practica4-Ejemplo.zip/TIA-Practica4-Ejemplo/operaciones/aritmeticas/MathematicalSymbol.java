package operaciones.aritmeticas;

public enum MathematicalSymbol 
{
	PLUS, MINUS, MULTIPLICATION, DIVISION
}
