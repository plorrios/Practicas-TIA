package MantenimientoDeCarreteras;

import java.util.Random;

import org.opt4j.core.genotype.IntegerGenotype;
import org.opt4j.core.problem.Creator;

public class CreatorMantCarr implements Creator<IntegerGenotype> 
{
	public IntegerGenotype create() 
	{
		IntegerGenotype genotipo = new IntegerGenotype(1, Datos.NUM_TURNOS ); //rango de turnos [1..3]
		
		// el genotipo estara formado por turnos elegidos al azar en el rango [1..3]
		// en nuestro caso la poblacion sera un conjunto de invididuos, donde cada invididuo son 10 enteros (las cuadrillas)
		genotipo.init(new Random(), Datos.NUM_CUADRILLAS);
		
		return genotipo;
	}
	
}
